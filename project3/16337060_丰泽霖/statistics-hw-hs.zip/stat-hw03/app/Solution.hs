import           Isumi.StatisticsHW.Ch03.Solution
