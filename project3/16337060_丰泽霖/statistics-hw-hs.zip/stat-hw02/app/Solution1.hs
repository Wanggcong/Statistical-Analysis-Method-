import           Zelinf.StatisticsHW.Ch02.Solution1
