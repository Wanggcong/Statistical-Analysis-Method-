import qualified Zelinf.StatisticsHW.Ch01.S4   as S4

main :: IO ()
main = S4.main
